package problem2;

import java.util.Scanner;

public class Problem2 {

	public static void main(String[] args) {
		calcBMI();	
	}

	private static void calcBMI() {
		double height, weight, BMI;
		char choice;
	  	Scanner sc = new Scanner(System.in);
	  	System.out.println("Use I or M to choose between imperial or metric measurements.");
	  	choice = sc.next().charAt(0);
	  	while (choice != 'I'&& choice != 'M') {
	  		System.out.println("Please use capital I or capital M for imperial or metric");
	  		choice = sc.next().charAt(0);
	  		
	  	}
	  		//getting height input from user
	  		
	  		if (choice == 'I' ) {
	  			System.out.println("Please enter your height in inches");
		  		height = sc.nextFloat();
		  		//getting weight input from user
		  		System.out.println("Please enter your weight in pounds");
		  		weight = sc.nextFloat();
		  		//System.out.println("This is the height"+ height);
		  		BMI = ((703*weight)/(Math.pow(height,2)));
		  		System.out.println("Your BMI is "+ BMI);
		  		getChart();
	  		}
	  		else if (choice == 'M' ) {
	  			System.out.println("Please enter your height in meters");
		  		height = sc.nextFloat();
		  		//getting weight input from user
		  		System.out.println("Please enter your weight in kilograms");
		  		weight = sc.nextFloat();
		  		// test System.out.println("This is the height"+ height);
		  		BMI = (weight/(Math.pow(height,2)));
		  		System.out.println("Your BMI is "+ BMI);
		  		getChart();
	  		}
	}
	private static void getChart() {
	System.out.println("BMI Categories: ");
	System.out.println("Underweight = 18.5");
	System.out.println("Overweight = 25-29.9");
	System.out.println("Obesity = BMI of 30 or greater");
		
	}

}
