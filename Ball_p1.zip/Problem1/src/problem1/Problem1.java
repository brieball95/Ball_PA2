package problem1;

import java.util.Scanner;

public class Problem1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 getNum();
	}
	
    private static void getNum(){
        int code = 0, codeSize = 0, eCode = 0;
        String ints, encoded,decoded;
        Scanner sc = new Scanner(System.in);
        
        while (codeSize!= 4){
            System.out.println("Enter a four digit code:");
            ints = sc.nextLine();
            codeSize = ints.length();
            
            if (codeSize == 4){
             code = Integer.parseInt(ints);
            }
            else{
             System.out.println("Please enter a four digit code");
            }
        }
        encoded = encryption(code);
        System.out.println("The encoded number is: " + encoded);
        eCode = Integer.parseInt(encoded);
        
        decoded = decryption(eCode);
        System.out.println("The encoded number is: " + decoded);
       }

    private static String encryption(int code) {
        int a, b, c, d; // to break up the code
        int a2,b2,c2,d2; //to switch up the code
        
        a = code / 1000;
        b = code / 100 % 10;
        c = code / 10 % 10;
        d = code % 10;
        
        //System.out.println(a + "" + b + "" + c+ "" + d);
        a = (a + 7) % 10;
        b = (b + 7 ) % 10;
        c = (c + 7) % 10;
        d = (d + 7) % 10;
        
        // System.out.println(a + "" + b + "" + c+ "" + d);
        // Testing function
        c2 = a;
        d2 = b;
        a2 = c;
        b2 = d;
        // System.out.println(a2 + "" + b2 + "" + c2 + "" + d2);
        //string to be decoded
        String encoded = new String();
        encoded = Integer.toString(a2);
        encoded += Integer.toString(b2);
        encoded += Integer.toString(c2);
        encoded += Integer.toString(d2);
        
        return encoded;
    }

    private static String decryption(int eCode) {
        int a2, b2, c2, d2; // to break up the code
        int a,b,c,d; //to switch up the code to normal
        
        a2 = eCode / 1000;
        b2 = eCode / 100 % 10;
        c2 = eCode / 10 % 10;
        d2 = eCode % 10;
        
        // System.out.println(a2 + "" + b2 + "" + c2 + "" + d2);
        a2 = (a2 - 7 + 10) % 10;
        b2 = (b2 - 7 + 10) % 10;
        c2 = (c2 - 7 + 10) % 10;
        d2 = (d2 - 7 + 10) % 10;
        
        //System.out.println(a2 + "" + b2 + "" + c2 + "" + d2);
        c = a2;
        d = b2;
        a = c2;
        b = d2;
        // System.out.println(a + "" + b + "" + c + "" + d);
        //string to be decoded
        String decoded = new String();
        decoded = Integer.toString(a);
        decoded += Integer.toString(b);
        decoded += Integer.toString(c);
        decoded += Integer.toString(d);
        
        return decoded;
    }
}
